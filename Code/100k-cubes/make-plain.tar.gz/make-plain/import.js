// App.js
import "./styles.css";
import * as THREE from "three";
import { BasicThreeDemo } from "./BasicThreeDemo";
import { Spheres } from "./spheres";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls";
import gsap from "gsap"; // /node_modules/gsap/gsap-core.js
import createInputEvents from "simple-input-events"; // /node_modules/simple-input-events/simple-input-events.js

// BasicThreeDemo.js
import "./styles.css";
import * as THREE from "three";
import Stats from "stats.js"; // /node_modules/stats.js/build/stats.min.js

// index.js
import { App } from "./App";
import debounce from "debounce"; // /node_modules/debounce/index.js

// spheres.js
import * as THREE from "three";
import random from "random"; // node_modules/random/index.js
